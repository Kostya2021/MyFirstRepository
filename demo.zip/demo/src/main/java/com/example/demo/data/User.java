package com.example.demo.data;


import javax.persistence.*;


@Entity
@Table(name = "user")
public class User {


    private String name;
    private int age;
    private Long id;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    public Long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public User(){
    }

    public User(String name, int age){
        this.name = name;
        this.age = age;
    }

    public User(String name){
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }





}
