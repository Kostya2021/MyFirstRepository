package com.example.demo;

import com.example.demo.data.User;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;

@SpringBootApplication
@RestController
public class DemoApplication {


    public static void main(String[] args) {
        SpringApplication.run(DemoApplication.class, args);
    }

    @GetMapping("/hello")
    public String hello(@RequestParam(value = "name", defaultValue = "World") String name) {
        return String.format("Hello %s!", name);
    }

    @GetMapping("/userbyid")
    public String getUser(@RequestParam(value = "id", defaultValue = "0") Long id) {

        StandardServiceRegistry ssr = new StandardServiceRegistryBuilder().configure().build();
        Metadata meta = new MetadataSources(ssr).getMetadataBuilder().build();
        SessionFactory factory = meta.getSessionFactoryBuilder().build();
        Session session = factory.openSession();

        session.beginTransaction();

        User user = session.get(User.class,id);
        session.flush();

        String userObjectMappedToJSONString = null;
        ObjectMapper om = new ObjectMapper();
        om.configure(SerializationFeature.FAIL_ON_EMPTY_BEANS,false);
        try {
            userObjectMappedToJSONString = om.writeValueAsString(user);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }

        return userObjectMappedToJSONString;
    }

    @GetMapping("/users")
    public String getUsers(){
        ArrayList<User> list = new ArrayList<>();
        long id = 1;
        User user = null;

        StandardServiceRegistry ssr = new StandardServiceRegistryBuilder().configure().build();
        Metadata meta = new MetadataSources(ssr).getMetadataBuilder().build();
        SessionFactory factory = meta.getSessionFactoryBuilder().build();
        Session session = factory.openSession();
        session.beginTransaction();

        do {
            user = session.get(User.class,id);
            list.add(user);
            id++;
            if (session.get(User.class,id)==null){
                break;
            }
        }
        while (user!=null);
        
        session.flush();
        session.close();

        String userObjectMappedToJSONString = null;
        ObjectMapper om = new ObjectMapper();
        om.configure(SerializationFeature.FAIL_ON_EMPTY_BEANS,false);
        try {
            userObjectMappedToJSONString = om.writeValueAsString(list);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }

        return userObjectMappedToJSONString;
    }

    @PostMapping("/createuser")
    public String createUser(@RequestParam (value = "name") String name) {
        User user = new User(name);
        user.setAge(25);

        StandardServiceRegistry ssr = new StandardServiceRegistryBuilder().configure().build();
        Metadata meta = new MetadataSources(ssr).getMetadataBuilder().build();
        SessionFactory factory = meta.getSessionFactoryBuilder().build();
        Session session = factory.openSession();

        session.beginTransaction();

        session.persist(user);

        session.flush();
        session.close();

        String userObjectMappedToJSONString = null;
        ObjectMapper om = new ObjectMapper();
        om.configure(SerializationFeature.FAIL_ON_EMPTY_BEANS,false);
        try {
            userObjectMappedToJSONString = om.writeValueAsString(user);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }

        return userObjectMappedToJSONString;
    }

    @PutMapping("/userupdate")
    public String updateUser(@RequestParam("id") Long id,
                             @RequestParam("name") String name)
    {
        User user = new User();
        StandardServiceRegistry ssr = new StandardServiceRegistryBuilder().configure().build();
        Metadata meta = new MetadataSources(ssr).getMetadataBuilder().build();
        SessionFactory factory = meta.getSessionFactoryBuilder().build();
        Session session = factory.openSession();

        session.beginTransaction();
        user = session.get(User.class,id);
        user.setName(name);
        user.setAge(30);

        session.update(user);

        session.flush();
        session.close();

        String userObjectMappedToJSONString = null;
        ObjectMapper om = new ObjectMapper();
        om.configure(SerializationFeature.FAIL_ON_EMPTY_BEANS,false);
        try {
            userObjectMappedToJSONString = om.writeValueAsString(user);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }

        return userObjectMappedToJSONString;
    }



}

/*
(@PathVariable long id, @RequestBody User user)
 */